from flask import Flask, render_template, request, redirect, url_for, session, jsonify
import sqlite3, os, math
from functools import wraps
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "smartbus-change-this-secret")
DB_PATH = os.environ.get("DB_PATH", "smartbus.db")

def db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = db()
    conn.executescript("""
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        role TEXT NOT NULL CHECK(role IN ('admin','driver')),
        driver_name TEXT
    );
    CREATE TABLE IF NOT EXISTS buses (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        bus_number TEXT UNIQUE NOT NULL,
        route TEXT NOT NULL,
        driver_id INTEGER,
        lat REAL,
        lng REAL,
        updated_at TEXT,
        FOREIGN KEY(driver_id) REFERENCES users(id)
    );
    """)
    admin = conn.execute("SELECT id FROM users WHERE username='admin'").fetchone()
    if not admin:
        conn.execute(
            "INSERT INTO users(username,password,role) VALUES(?,?,?)",
            ("admin", generate_password_hash("admin123"), "admin")
        )
    conn.commit()
    conn.close()

def login_required(role=None):
    def deco(fn):
        @wraps(fn)
        def wrapper(*args, **kwargs):
            if "user_id" not in session:
                return redirect(url_for("login"))
            if role and session.get("role") != role:
                return redirect(url_for("dashboard"))
            return fn(*args, **kwargs)
        return wrapper
    return deco

@app.route("/")
def home():
    return redirect(url_for("dashboard") if "user_id" in session else url_for("login"))

@app.route("/health")
def health():
    return jsonify(status="ok", service="SmartBus Flow")

@app.route("/login", methods=["GET","POST"])
def login():
    error = None
    if request.method == "POST":
        username = request.form.get("username","").strip()
        password = request.form.get("password","")
        conn = db()
        user = conn.execute("SELECT * FROM users WHERE username=?", (username,)).fetchone()
        conn.close()
        if user and check_password_hash(user["password"], password):
            session["user_id"] = user["id"]
            session["username"] = user["username"]
            session["role"] = user["role"]
            return redirect(url_for("dashboard"))
        error = "Invalid username or password."
    return render_template("login.html", error=error)

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))

@app.route("/dashboard")
@login_required()
def dashboard():
    if session["role"] == "admin":
        return redirect(url_for("admin"))
    return redirect(url_for("driver"))

@app.route("/admin", methods=["GET","POST"])
@login_required("admin")
def admin():
    conn = db()
    if request.method == "POST":
        action = request.form.get("action")
        if action == "driver":
            username = request.form.get("username","").strip()
            password = request.form.get("password","")
            name = request.form.get("driver_name","").strip()
            if username and password and name:
                try:
                    conn.execute(
                        "INSERT INTO users(username,password,role,driver_name) VALUES(?,?,?,?)",
                        (username, generate_password_hash(password), "driver", name)
                    )
                    conn.commit()
                except sqlite3.IntegrityError:
                    pass
        elif action == "bus":
            number = request.form.get("bus_number","").strip()
            route = request.form.get("route","").strip()
            driver_id = request.form.get("driver_id") or None
            if number and route:
                try:
                    conn.execute(
                        "INSERT INTO buses(bus_number,route,driver_id) VALUES(?,?,?)",
                        (number, route, driver_id)
                    )
                    conn.commit()
                except sqlite3.IntegrityError:
                    pass
    drivers = conn.execute("SELECT * FROM users WHERE role='driver' ORDER BY id DESC").fetchall()
    buses = conn.execute("""
        SELECT b.*, u.driver_name, u.username
        FROM buses b LEFT JOIN users u ON b.driver_id=u.id
        ORDER BY b.id DESC
    """).fetchall()
    conn.close()
    return render_template("admin.html", drivers=drivers, buses=buses, username=session["username"])

@app.route("/driver")
@login_required("driver")
def driver():
    conn = db()
    buses = conn.execute(
        "SELECT * FROM buses WHERE driver_id=? ORDER BY id DESC",
        (session["user_id"],)
    ).fetchall()
    conn.close()
    return render_template("driver.html", buses=buses, username=session["username"])

@app.post("/api/location")
@login_required("driver")
def update_location():
    data = request.get_json(silent=True) or {}
    try:
        lat, lng = float(data["lat"]), float(data["lng"])
    except (KeyError, TypeError, ValueError):
        return jsonify(error="Invalid coordinates"), 400
    conn = db()
    bus = conn.execute(
        "SELECT id FROM buses WHERE driver_id=? ORDER BY id LIMIT 1",
        (session["user_id"],)
    ).fetchone()
    if not bus:
        conn.close()
        return jsonify(error="No bus assigned"), 404
    conn.execute(
        "UPDATE buses SET lat=?, lng=?, updated_at=datetime('now') WHERE id=?",
        (lat, lng, bus["id"])
    )
    conn.commit()
    conn.close()
    return jsonify(status="updated", lat=lat, lng=lng)

@app.get("/api/buses")
def buses_api():
    conn = db()
    rows = conn.execute("""
        SELECT b.id,b.bus_number,b.route,b.lat,b.lng,b.updated_at,u.driver_name
        FROM buses b LEFT JOIN users u ON b.driver_id=u.id
        ORDER BY b.bus_number
    """).fetchall()
    conn.close()
    return jsonify([dict(r) for r in rows])

@app.get("/track")
def track():
    return render_template("tracking.html")

@app.post("/api/eta")
def eta():
    data = request.get_json(silent=True) or {}
    try:
        a = (float(data["lat"]), float(data["lng"]))
        b = (float(data["dest_lat"]), float(data["dest_lng"]))
    except (KeyError, TypeError, ValueError):
        return jsonify(error="Invalid coordinates"), 400
    # Haversine straight-line estimate. Real road ETA can be added later with routing API.
    r = 6371
    p1,p2 = math.radians(a[0]), math.radians(b[0])
    dp = math.radians(b[0]-a[0])
    dl = math.radians(b[1]-a[1])
    h = math.sin(dp/2)**2 + math.cos(p1)*math.cos(p2)*math.sin(dl/2)**2
    distance = 2*r*math.asin(math.sqrt(h))
    minutes = (distance / 25) * 60 if distance else 0
    return jsonify(distance_km=round(distance,2), eta_minutes=round(minutes))

@app.route("/setup")
def setup():
    init_db()
    return "Database initialized. Remove or protect /setup before production."

init_db()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 5000)))
