# SmartBus Flow

Fresh Flask + SQLite SmartBus tracking MVP.

## Default admin
- Username: `admin`
- Password: `admin123`

Change the admin password before real use.

## Run locally
```bash
pip install -r requirements.txt
python app.py
```

Open http://127.0.0.1:5000

## Main features
- Admin login
- Driver login
- Multiple drivers and buses
- Bus/driver assignment
- Driver phone GPS
- Live bus list/map
- Where is my Bus
- Distance and basic ETA
- SQLite database
- `/health` health check
- Logout

The first ETA implementation uses straight-line distance and an assumed average speed of 25 km/h. Road-aware ETA can be connected to a routing service later.
